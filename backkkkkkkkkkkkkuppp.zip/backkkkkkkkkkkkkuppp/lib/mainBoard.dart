// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wallpaperapp/Explore/explore.dart';
import 'package:wallpaperapp/Home/home.dart';
import 'package:wallpaperapp/MyProfile/myProfile.dart';
import 'package:wallpaperapp/Datas.dart';

class MainBoard extends StatefulWidget {
  const MainBoard({super.key});

  @override
  State<MainBoard> createState() => _MainBoardState();
}

class _MainBoardState extends State<MainBoard> {
  static final keyMyProfile = GlobalKey<MyProfileState>();
  int selIndex = 0;
  List<Widget> items = [Home(), Explore(), MyProfile(key: keyMyProfile)];
  bool isDarkMode() {
    return Theme.of(context).brightness == Brightness.dark;
  }

  @override
  Widget build(BuildContext context) {
    final myDatas = Provider.of<MyWallAppDatas>(context, listen: true);
    myDatas
        .loadLikedPhotosToList(); //loading liked photos array as soon as app is started
    return Scaffold(
      body: Container(
        color: isDarkMode() ? Colors.black : Colors.white,
        child: IndexedStack(
          index: selIndex,
          children: items,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        onTap: (value) {
          FocusScope.of(context)
              .unfocus(); //--------------------------------------------------------------
          selIndex = value;
          setState(() {});
          if (selIndex == 2) {
            keyMyProfile.currentState?.updatePage();
          }
        },
        currentIndex: selIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: "Explore",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "My Profile",
          ),
        ],
      ),
    );
  }
}
