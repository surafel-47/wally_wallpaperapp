// ignore_for_file: non_constant_identifier_names, prefer_const_constructors, prefer_const_literals_to_create_immutables, file_names

import 'dart:ui';
import 'package:flutter/material.dart';
import 'orientationSelect.dart';
import 'mainColorSelect.dart';
import 'catagorySelect.dart';

import 'package:wallpaperapp/Datas.dart';

class SearchFilter extends StatelessWidget {
  final keyMainColorSelect = GlobalKey<MainColorSelectorWidgetState>();
  final keyOriSelect = GlobalKey<OrientaionSelectWidgetState>();
  final keyCatagSelect = GlobalKey<CatagorySelectWidgetState>();
  double scrW = 0;
  double scrH = 0;

  @override
  Widget build(BuildContext context) {
    scrW = MediaQuery.of(context).size.width;
    scrH = MediaQuery.of(context).size.height;
    return Stack(
      children: [
        BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Container(),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              colors: [
                Colors.white.withOpacity(0.01),
                Colors.white.withOpacity(0.1)
              ],
            ),
          ),
        ),
        Center(
          child: Container(
            width: scrW * 0.9,
            height: scrH * 0.8,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(height: scrH * 0.02),
                OrientaionSelectWidget(key: keyOriSelect),
                CatagorySelectWidget(key: keyCatagSelect),
                MainColorSelectorWidget(key: keyMainColorSelect),
                SizedBox(height: scrH * 0.02),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      child: Text("Clear"),
                      onPressed: () {
                        myWallAppDatas.Category = "All";
                        myWallAppDatas.MainColors = "All";
                        myWallAppDatas.Orientation = "All";
                        keyOriSelect.currentState!.updateState();
                        keyCatagSelect.currentState!.updateState();
                        keyMainColorSelect.currentState!.updateState();
                        // myWallAppDatas.displayData();
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 10, right: 10),
                      child: ElevatedButton(
                        child: Text("Apply"),
                        onPressed: () {
                          //------------afer doing
                          Navigator.of(context).pop();
                        },
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
