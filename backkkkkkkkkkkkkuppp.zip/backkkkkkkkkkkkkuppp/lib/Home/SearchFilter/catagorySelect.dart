import 'package:flutter/material.dart';
import 'package:wallpaperapp/Datas.dart';

class CatagorySelectWidget extends StatefulWidget {
  const CatagorySelectWidget({super.key});

  @override
  State<CatagorySelectWidget> createState() => CatagorySelectWidgetState();
}

class CatagorySelectWidgetState extends State<CatagorySelectWidget> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    selItem = myWallAppDatas.Category;
  }

  //to Refresh
  void updateState() {
    selItem = myWallAppDatas.Category;
    setState(() {});
  }

  double scrW = 0;
  double scrH = 0;
  String selItem = "";
  List<String> itemss = [
    "All",
    "Backgrounds",
    "Food",
    "Nature",
    "Animals",
    "Music",
    "Sports",
    "Travel",
    "Buildings",
    "Fashion"
  ];
  @override
  Widget build(BuildContext context) {
    scrW = MediaQuery.of(context).size.width;
    scrH = MediaQuery.of(context).size.height;
    return Container(
      width: scrW * 0.8,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: 'Categories',
          labelStyle:
              TextStyle(fontSize: scrW * 0.06, fontWeight: FontWeight.bold),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        child: Material(
          child: DropdownButton(
            menuMaxHeight: scrH * 0.4,
            value: selItem,
            items: itemss.map((e) {
              return DropdownMenuItem(
                value: e,
                child: Text(e),
              );
            }).toList(),
            onChanged: (value) {
              selItem = value!;
              myWallAppDatas.Category = value;
              //myWallAppDatas.displayData();
              setState(() {});
            },
          ),
        ),
      ),
    );
  }
}
