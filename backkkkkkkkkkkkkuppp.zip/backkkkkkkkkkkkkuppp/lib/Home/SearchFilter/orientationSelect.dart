import 'package:flutter/material.dart';
import 'package:wallpaperapp/Datas.dart';

class OrientaionSelectWidget extends StatefulWidget {
  const OrientaionSelectWidget({super.key});

  @override
  State<OrientaionSelectWidget> createState() => OrientaionSelectWidgetState();
}

class OrientaionSelectWidgetState extends State<OrientaionSelectWidget> {
  double scrW = 0;
  double scrH = 0;
  int selIndex = myWallAppDatas.Orientation == "All"
      ? 1
      : myWallAppDatas.Orientation == "Vertical"
          ? 2
          : 3;
//to Refresh
  void updateState() {
    selIndex = myWallAppDatas.Orientation == "All"
        ? 1
        : myWallAppDatas.Orientation == "Vertical"
            ? 2
            : 3;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    scrW = MediaQuery.of(context).size.width;
    scrH = MediaQuery.of(context).size.height;
    return Container(
      width: scrW * 0.8,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: 'Orientation',
          labelStyle:
              TextStyle(fontSize: scrW * 0.06, fontWeight: FontWeight.bold),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        child: Material(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Radio(
                    value: 1,
                    groupValue: selIndex,
                    onChanged: (value) {
                      selIndex = value!;
                      myWallAppDatas.Orientation = "All";
                      setState(() {});
                    },
                  ),
                  Icon(Icons.all_inbox),
                ],
              ),
              Column(
                children: [
                  Radio(
                    value: 2,
                    groupValue: selIndex,
                    onChanged: (value) {
                      selIndex = value!;
                      myWallAppDatas.Orientation = "Vertical";
                      setState(() {});
                    },
                  ),
                  Icon(Icons.portrait_rounded),
                ],
              ),
              Column(
                children: [
                  Radio(
                    value: 3,
                    groupValue: selIndex,
                    onChanged: (value) {
                      selIndex = value!;
                      myWallAppDatas.Orientation = "Horizontal";
                      setState(() {});
                    },
                  ),
                  Icon(Icons.landscape_outlined),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
