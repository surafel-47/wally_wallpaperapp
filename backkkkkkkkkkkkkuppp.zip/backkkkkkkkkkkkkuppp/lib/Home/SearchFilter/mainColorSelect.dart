import 'package:flutter/material.dart';
import 'package:wallpaperapp/Datas.dart';

class MainColorSelectorWidget extends StatefulWidget {
  const MainColorSelectorWidget({super.key});

  @override
  State<MainColorSelectorWidget> createState() =>
      MainColorSelectorWidgetState();
}

class MainColorSelectorWidgetState extends State<MainColorSelectorWidget> {
  Color selectedColor = Colors.lightBlue;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    for (int i = 0; i < colorList.length; i++) {
      if (colorList[i][0] == myWallAppDatas.MainColors) {
        selectedColor = colorList[i][1];
      }
    }
  }

  //to Refresh
  void updateState() {
    for (int i = 0; i < colorList.length; i++) {
      if (colorList[i][0] == myWallAppDatas.MainColors) {
        selectedColor = colorList[i][1];
      }
    }
    setState(() {});
  }

  double scrW = 0;
  double scrH = 0;
  String selItem = "";
  List<List<dynamic>> colorList = [
    ['All', Colors.lightBlue],
    ['Black', Colors.black],
    ['Red', Colors.red],
    ['Blue', Colors.blue],
    ['Pink', Colors.pink],
    ['White', Colors.white],
    ['Brown', Colors.brown],
    ['Orange', Colors.orange],
    ['Green', Colors.green],
  ];

  @override
  Widget build(BuildContext context) {
    scrW = MediaQuery.of(context).size.width;
    scrH = MediaQuery.of(context).size.height;
    return Container(
      width: scrW * 0.8,
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: 'Color Theme',
          labelStyle:
              TextStyle(fontSize: scrW * 0.06, fontWeight: FontWeight.bold),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        child: Material(
          child: Container(
            height: scrH * 0.2,
            width: scrW * 0.3,
            child: GridView.builder(
              itemCount: colorList.length,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    selectedColor = colorList[index][1];
                    myWallAppDatas.MainColors = colorList[index][0];
                    // myWallAppDatas.displayData();
                    setState(() {});
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        color: selectedColor == colorList[index][1]
                            ? Color.fromARGB(255, 206, 215, 220)
                            : null),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: scrW * 0.08,
                          decoration: BoxDecoration(
                            color: colorList[index][1],
                            shape: BoxShape.circle,
                          ),
                          child: Text(" "),
                        ),
                        Text(
                          colorList[index][0],
                          softWrap: true,
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
