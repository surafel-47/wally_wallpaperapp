// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:wallpaperapp/Datas.dart';
import 'package:wallpaperapp/Home/picsGridView.dart';
import 'SearchFilter/searchFilter.dart';

class Home extends StatelessWidget {
  double scrW = 0;
  double scrH = 0;
  final keyPicsGridView = GlobalKey<PicsGridViewState>();
  final textFieldValue = TextEditingController();
  @override
  Widget build(BuildContext context) {
    scrW = MediaQuery.of(context).size.width;
    scrH = MediaQuery.of(context).size.height;
    return Column(
      children: [
        SizedBox(height: scrH * 0.03),
        Row(
          children: [
            SizedBox(width: scrH * 0.02),
            Container(
              width: scrW * 0.8,
              height: scrH * 0.07,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: const Color.fromARGB(255, 255, 255, 255),
                boxShadow: const [
                  BoxShadow(
                      color: Color.fromARGB(255, 213, 211, 211),
                      blurRadius: 5,
                      spreadRadius: 5),
                ],
              ),
              child: TextField(
                controller: textFieldValue,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  suffixIcon: InkWell(
                    onTap: () {
                      myWallAppDatas.q = textFieldValue.text;
                      myWallAppDatas.displayData();
                      keyPicsGridView.currentState!.updateState();
                    },
                    child: const Icon(Icons.search),
                  ),
                  hintText: 'Search Wallpapers!',
                  prefix: const Text("    "),
                ),
                focusNode: null,
              ),
            ),
            IconButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return SearchFilter();
                  },
                );
              },
              icon: Icon(Icons.filter_list_outlined),
            ),
          ],
        ),
        SizedBox(height: scrH * 0.03),
        PicsGridView(key: keyPicsGridView),
      ],
    );
  }
}
